from django.urls import path
from .views import *
from .a1 import *
urlpatterns = [

    path('', home),
    path('home/',home),
    path('datetime/',datetime1),
    path('index/',index),
    path('index2/',index2),
    path('veggi/',index3),
    path('db/', index4),
]